
using System;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace RemoteInfoClient
{
	
	public partial class ViewFileController : UIViewController
	{
		#region Constructors

		// The IntPtr and NSCoder constructors are required for controllers that need 
		// to be able to be created from a xib rather than from managed code

		public ViewFileController (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		[Export("initWithCoder:")]
		public ViewFileController (NSCoder coder) : base(coder)
		{
			Initialize ();
		}

		string fileContents;
		
		public ViewFileController (string fileName, string fileContents) : base(null, NSBundle.MainBundle)
		{
			Initialize ();
			this.Title = fileName;
			this.fileContents = fileContents;
		}

		void Initialize ()
		{
		}
		
		#endregion
		
		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
		
			this.textView.Text = this.fileContents ?? string.Empty;
		}

		
	}
}


namespace RemoteInfoClient
{
	public partial class TestController : UIViewController
	{
		#region Constructors

		// The IntPtr and NSCoder constructors are required for controllers that need 
		// to be able to be created from a xib rather than from managed code

		public TestController (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		[Export("initWithCoder:")]
		public TestController (NSCoder coder) : base(coder)
		{
			Initialize ();
		}
		
		string fileContents;

		public TestController (string fileName, string fileContents) : base("MainWindow", null)
		{
			Initialize ();
			this.Title = fileName;
			this.fileContents = fileContents;
		}

		void Initialize ()
		{
		}
		
		#endregion
		
		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
			
			this.textView.Text = this.fileContents;
		}

	}


	// Base type probably should be MonoTouch.UIKit.UIViewController or subclass
	[MonoTouch.Foundation.Register("TestController")]
	public partial class TestController {
		
		[MonoTouch.Foundation.Connect("textView")]
		private MonoTouch.UIKit.UITextView textView {
			get {
				return ((MonoTouch.UIKit.UITextView)(this.GetNativeField("textView")));
			}
			set {
				this.SetNativeField("textView", value);
			}
		}
	}
}
