
using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace RemoteInfoClient
{
	public partial class ViewTextFileController : UIViewController
	{
		#region Constructors

		// The IntPtr and NSCoder constructors are required for controllers that need 
		// to be able to be created from a xib rather than from managed code

		public ViewTextFileController (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		[Export("initWithCoder:")]
		public ViewTextFileController (NSCoder coder) : base(coder)
		{
			Initialize ();
		}

		string fileContents;

		public ViewTextFileController (string fileName, string fileContents) :
			base("ViewTextFileController", null)
		{
			Initialize ();
			this.Title = fileName;
			this.fileContents = fileContents;
		}

		void Initialize ()
		{
		}
		
		#endregion
		
		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
			
			this.textView.Text = this.fileContents;
		}
		
		
	}
}
